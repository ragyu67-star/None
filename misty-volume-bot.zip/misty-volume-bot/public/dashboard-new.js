// Dashboard State
const state = {
    isRunning: false,
    stats: {
        totalVolume: 0,
        totalTransactions: 0,
        successRate: 0,
        activeWallets: 0,
        totalBalance: 0
    },
    trades: [],
    logs: [],
    currentLogLevel: 'all',
    startTime: null,
    charts: {
        volume: null,
        wallet: null
    }
};

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    initializeCharts();
    setupEventListeners();
    startPolling();
    updateStatus();
});

// Setup event listeners
function setupEventListeners() {
    // Toggle bot
    document.getElementById('toggle-bot').addEventListener('click', toggleBot);
    
    // Emergency stop
    document.getElementById('emergency-stop').addEventListener('click', emergencyStop);
    
    // Clear trades
    document.getElementById('clear-trades').addEventListener('click', clearTrades);
    
    // Timeframe buttons
    document.querySelectorAll('.timeframe-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.timeframe-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            updateVolumeChart(e.target.dataset.timeframe);
        });
    });
    
    // Log filters
    document.querySelectorAll('.log-filter').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.log-filter').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            state.currentLogLevel = e.target.dataset.level;
            filterLogs();
        });
    });
}

// API Calls
async function toggleBot() {
    const btn = document.getElementById('toggle-bot');
    const loadingOverlay = document.getElementById('loading-overlay');
    
    try {
        loadingOverlay.classList.add('active');
        
        if (state.isRunning) {
            await fetch('/api/stop', { method: 'POST' });
            state.isRunning = false;
            state.startTime = null;
            btn.innerHTML = `
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <polygon points="5 3 19 12 5 21 5 3" stroke-width="2"/>
                </svg>
                Start Bot
            `;
            btn.classList.remove('btn-emergency');
            btn.classList.add('btn-primary');
            addLog('info', 'Bot stopped successfully');
        } else {
            await fetch('/api/start', { method: 'POST' });
            state.isRunning = true;
            state.startTime = Date.now();
            btn.innerHTML = `
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <rect x="6" y="4" width="4" height="16" stroke-width="2"/>
                    <rect x="14" y="4" width="4" height="16" stroke-width="2"/>
                </svg>
                Stop Bot
            `;
            btn.classList.remove('btn-primary');
            btn.classList.add('btn-emergency');
            addLog('info', 'Bot started successfully');
        }
        
        updateStatus();
    } catch (error) {
        console.error('Error toggling bot:', error);
        addLog('error', `Failed to ${state.isRunning ? 'stop' : 'start'} bot: ${error.message}`);
    } finally {
        loadingOverlay.classList.remove('active');
    }
}

async function emergencyStop() {
    if (!state.isRunning) return;
    
    if (confirm('Are you sure you want to perform an emergency stop?')) {
        try {
            await fetch('/api/stop', { method: 'POST' });
            state.isRunning = false;
            state.startTime = null;
            
            const btn = document.getElementById('toggle-bot');
            btn.innerHTML = `
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <polygon points="5 3 19 12 5 21 5 3" stroke-width="2"/>
                </svg>
                Start Bot
            `;
            btn.classList.remove('btn-emergency');
            btn.classList.add('btn-primary');
            
            addLog('warn', 'Emergency stop executed');
            updateStatus();
        } catch (error) {
            console.error('Error during emergency stop:', error);
            addLog('error', `Emergency stop failed: ${error.message}`);
        }
    }
}

async function fetchStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        state.isRunning = data.isRunning;
        
        if (data.stats) {
            state.stats = {
                totalVolume: data.stats.totalVolume || 0,
                totalTransactions: data.stats.totalTransactions || 0,
                successRate: data.stats.successRate || 0,
                activeWallets: data.stats.activeWallets || 0,
                totalBalance: data.stats.totalBalance || 0
            };
        }
        
        if (data.config) {
            updateConfig(data.config);
        }
        
        updateStatus();
        updateStats();
    } catch (error) {
        console.error('Error fetching status:', error);
        updateConnectionStatus(false);
    }
}

async function fetchLogs() {
    try {
        const response = await fetch('/api/logs');
        const data = await response.json();
        
        if (data.logs && Array.isArray(data.logs)) {
            state.logs = data.logs;
            filterLogs();
        }
    } catch (error) {
        console.error('Error fetching logs:', error);
    }
}

// UI Updates
function updateStatus() {
    const statusBadge = document.getElementById('bot-status');
    const connectionStatus = document.getElementById('connection-status');
    
    if (state.isRunning) {
        statusBadge.innerHTML = '<span class="badge badge-running">Running</span>';
        updateConnectionStatus(true);
    } else {
        statusBadge.innerHTML = '<span class="badge badge-stopped">Stopped</span>';
    }
    
    updateUptime();
}

function updateConnectionStatus(connected) {
    const statusBadge = document.getElementById('connection-status');
    
    if (connected) {
        statusBadge.classList.remove('disconnected');
        statusBadge.classList.add('connected');
        statusBadge.innerHTML = `
            <span class="pulse"></span>
            <span class="text">Connected</span>
        `;
    } else {
        statusBadge.classList.remove('connected');
        statusBadge.classList.add('disconnected');
        statusBadge.innerHTML = `
            <span class="pulse"></span>
            <span class="text">Disconnected</span>
        `;
    }
}

function updateStats() {
    document.getElementById('total-volume').textContent = 
        `$${state.stats.totalVolume.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    
    document.getElementById('total-transactions').textContent = 
        state.stats.totalTransactions.toLocaleString();
    
    document.getElementById('success-rate').textContent = 
        `${state.stats.successRate.toFixed(1)}%`;
    
    document.getElementById('success-count').textContent = 
        `${Math.floor(state.stats.totalTransactions * state.stats.successRate / 100)} / ${state.stats.totalTransactions} successful`;
    
    document.getElementById('active-wallets').textContent = 
        `${state.stats.activeWallets} active`;
    
    document.getElementById('total-balance').textContent = 
        `${state.stats.totalBalance.toFixed(4)} SOL`;
    
    // Update transaction rate
    if (state.startTime) {
        const elapsed = (Date.now() - state.startTime) / 60000; // minutes
        const rate = elapsed > 0 ? (state.stats.totalTransactions / elapsed).toFixed(1) : 0;
        document.getElementById('tx-rate').textContent = `${rate} tx/min`;
    }
}

function updateConfig(config) {
    if (config.tokenAddress) {
        document.getElementById('token-address').textContent = config.tokenAddress;
    }
    
    if (config.buyRatio !== undefined) {
        const sellRatio = 100 - config.buyRatio;
        document.getElementById('trade-ratio').textContent = 
            `${config.buyRatio}% / ${sellRatio}%`;
    }
    
    if (config.network) {
        document.getElementById('network-env').textContent = config.network;
    }
    
    if (config.walletCount !== undefined) {
        document.getElementById('wallet-count').textContent = config.walletCount;
    }
}

function updateUptime() {
    if (state.startTime) {
        const elapsed = Math.floor((Date.now() - state.startTime) / 1000);
        const hours = Math.floor(elapsed / 3600);
        const minutes = Math.floor((elapsed % 3600) / 60);
        const seconds = elapsed % 60;
        
        let uptime = '';
        if (hours > 0) uptime += `${hours}h `;
        if (minutes > 0 || hours > 0) uptime += `${minutes}m `;
        uptime += `${seconds}s`;
        
        document.getElementById('system-uptime').textContent = uptime;
    } else {
        document.getElementById('system-uptime').textContent = '0s';
    }
}

function addTrade(type, amount, price) {
    const trade = {
        type,
        amount,
        price,
        timestamp: new Date()
    };
    
    state.trades.unshift(trade);
    if (state.trades.length > 50) {
        state.trades = state.trades.slice(0, 50);
    }
    
    renderTrades();
}

function renderTrades() {
    const container = document.getElementById('trades-container');
    
    if (state.trades.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" stroke-width="2"/>
                </svg>
                <p>No trades yet</p>
                <span>Start the bot to see trading activity</span>
            </div>
        `;
        return;
    }
    
    container.innerHTML = state.trades.map(trade => `
        <div class="trade-item">
            <div class="trade-header">
                <span class="trade-type trade-${trade.type}">${trade.type.toUpperCase()}</span>
                <span class="trade-time">${formatTime(trade.timestamp)}</span>
            </div>
            <div class="trade-details">
                <span>Amount: <span class="trade-amount">${trade.amount.toFixed(4)} SOL</span></span>
                <span>Price: <span class="trade-amount">$${trade.price.toFixed(2)}</span></span>
            </div>
        </div>
    `).join('');
}

function clearTrades() {
    if (state.trades.length === 0) return;
    
    if (confirm('Are you sure you want to clear all trades?')) {
        state.trades = [];
        renderTrades();
        addLog('info', 'Trade history cleared');
    }
}

function addLog(level, message) {
    const log = {
        level,
        message,
        timestamp: new Date()
    };
    
    state.logs.unshift(log);
    if (state.logs.length > 100) {
        state.logs = state.logs.slice(0, 100);
    }
    
    filterLogs();
}

function filterLogs() {
    const container = document.getElementById('logs-container');
    const filtered = state.currentLogLevel === 'all' 
        ? state.logs 
        : state.logs.filter(log => log.level === state.currentLogLevel);
    
    if (filtered.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" stroke-width="2"/>
                    <polyline points="14 2 14 8 20 8" stroke-width="2"/>
                </svg>
                <p>No ${state.currentLogLevel === 'all' ? '' : state.currentLogLevel} logs</p>
                <span>Logs will appear here</span>
            </div>
        `;
        return;
    }
    
    container.innerHTML = filtered.map(log => `
        <div class="log-item ${log.level}">
            <span class="log-timestamp">${formatTime(log.timestamp)}</span>
            <span class="log-message">${escapeHtml(log.message)}</span>
        </div>
    `).join('');
}

// Chart Initialization
function initializeCharts() {
    // Volume Chart
    const volumeCtx = document.getElementById('volume-chart').getContext('2d');
    state.charts.volume = new Chart(volumeCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Volume ($)',
                data: [],
                borderColor: '#00d9ff',
                backgroundColor: 'rgba(0, 217, 255, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(17, 24, 39, 0.95)',
                    titleColor: '#f8fafc',
                    bodyColor: '#94a3b8',
                    borderColor: 'rgba(0, 217, 255, 0.3)',
                    borderWidth: 1,
                    padding: 12,
                    displayColors: false
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        color: '#64748b',
                        font: {
                            family: "'JetBrains Mono', monospace",
                            size: 11
                        }
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        color: '#64748b',
                        font: {
                            family: "'JetBrains Mono', monospace",
                            size: 11
                        },
                        callback: (value) => '$' + value.toLocaleString()
                    }
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            }
        }
    });
    
    // Wallet Chart
    const walletCtx = document.getElementById('wallet-chart').getContext('2d');
    state.charts.wallet = new Chart(walletCtx, {
        type: 'doughnut',
        data: {
            labels: ['Active', 'Inactive'],
            datasets: [{
                data: [0, 100],
                backgroundColor: [
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(100, 116, 139, 0.2)'
                ],
                borderColor: [
                    '#10b981',
                    '#64748b'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#94a3b8',
                        font: {
                            family: "'Outfit', sans-serif",
                            size: 12
                        },
                        padding: 15
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(17, 24, 39, 0.95)',
                    titleColor: '#f8fafc',
                    bodyColor: '#94a3b8',
                    borderColor: 'rgba(0, 217, 255, 0.3)',
                    borderWidth: 1,
                    padding: 12
                }
            }
        }
    });
}

function updateVolumeChart(timeframe) {
    // Generate sample data based on timeframe
    const now = Date.now();
    const intervals = timeframe === '1h' ? 12 : timeframe === '6h' ? 24 : timeframe === '24h' ? 48 : 168;
    const intervalMs = timeframe === '1h' ? 300000 : timeframe === '6h' ? 900000 : timeframe === '24h' ? 1800000 : 3600000;
    
    const labels = [];
    const data = [];
    
    for (let i = intervals; i >= 0; i--) {
        const time = new Date(now - (i * intervalMs));
        labels.push(formatChartTime(time, timeframe));
        data.push(Math.random() * 1000);
    }
    
    state.charts.volume.data.labels = labels;
    state.charts.volume.data.datasets[0].data = data;
    state.charts.volume.update();
}

function updateWalletChart(active, total) {
    state.charts.wallet.data.datasets[0].data = [active, total - active];
    state.charts.wallet.update();
}

// Utility Functions
function formatTime(date) {
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    });
}

function formatChartTime(date, timeframe) {
    if (timeframe === '7d') {
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
    return date.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false 
    });
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Polling
function startPolling() {
    // Fetch status every 2 seconds
    setInterval(fetchStatus, 2000);
    
    // Fetch logs every 5 seconds
    setInterval(fetchLogs, 5000);
    
    // Update uptime every second
    setInterval(updateUptime, 1000);
    
    // Initial fetch
    fetchStatus();
    fetchLogs();
    
    // Simulate some initial data for demo
    setTimeout(() => {
        updateVolumeChart('1h');
        updateWalletChart(8, 10);
    }, 1000);
}

// Demo mode - simulate activity when bot is running
setInterval(() => {
    if (state.isRunning) {
        // Randomly add trades
        if (Math.random() > 0.7) {
            const type = Math.random() > 0.5 ? 'buy' : 'sell';
            const amount = Math.random() * 10;
            const price = 100 + (Math.random() * 50);
            addTrade(type, amount, price);
        }
        
        // Update stats
        state.stats.totalVolume += Math.random() * 100;
        state.stats.totalTransactions += Math.floor(Math.random() * 2);
        state.stats.successRate = 85 + (Math.random() * 10);
        updateStats();
    }
}, 5000);
