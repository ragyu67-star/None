class MistyDashboard {
    constructor() {
        this.isConnected = false;
        this.botRunning = false;
        this.updateInterval = null;
        this.charts = {};
        
        this.init();
    }

    init() {
        this.initializeCharts();
        this.setupEventListeners();
        this.startDataUpdates();
        feather.replace();
    }

    initializeCharts() {
        // Volume Chart
        const volumeCtx = document.getElementById('volume-chart').getContext('2d');
        this.charts.volume = new Chart(volumeCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Volume ($)',
                    data: [],
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    x: {
                        type: 'time',
                        time: {
                            unit: 'minute'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Volume: $' + context.parsed.y.toLocaleString();
                            }
                        }
                    }
                }
            }
        });

        // Wallet Chart (Doughnut)
        const walletCtx = document.getElementById('wallet-chart').getContext('2d');
        this.charts.wallet = new Chart(walletCtx, {
            type: 'doughnut',
            data: {
                labels: ['Active', 'Inactive'],
                datasets: [{
                    data: [0, 0],
                    backgroundColor: ['#198754', '#6c757d'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }

    setupEventListeners() {
        // Bot control buttons
        document.getElementById('toggle-bot').addEventListener('click', () => {
            this.toggleBot();
        });

        document.getElementById('emergency-stop').addEventListener('click', () => {
            this.emergencyStop();
        });

        // Clear trades button
        document.getElementById('clear-trades').addEventListener('click', () => {
            document.getElementById('trades-container').innerHTML = `
                <div class="text-center text-muted py-4">
                    <i data-feather="activity" size="48"></i>
                    <p class="mt-2">Trade history cleared.</p>
                </div>
            `;
            feather.replace();
        });

        // Log level filters
        document.querySelectorAll('[data-log-level]').forEach(button => {
            button.addEventListener('click', (e) => {
                document.querySelectorAll('[data-log-level]').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.filterLogs(e.target.dataset.logLevel);
            });
        });

        // Timeframe buttons
        document.querySelectorAll('[data-timeframe]').forEach(button => {
            button.addEventListener('click', (e) => {
                document.querySelectorAll('[data-timeframe]').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.updateVolumeChart(e.target.dataset.timeframe);
            });
        });
    }

    async toggleBot() {
        const button = document.getElementById('toggle-bot');
        const icon = button.querySelector('i');
        
        this.showLoading();
        
        try {
            const endpoint = this.botRunning ? '/api/stop' : '/api/start';
            const response = await fetch(endpoint, { method: 'POST' });
            const result = await response.json();
            
            if (response.ok) {
                this.botRunning = !this.botRunning;
                this.updateBotStatus();
                this.showNotification(result.message, 'success');
            } else {
                this.showNotification(result.error || 'Operation failed', 'error');
            }
        } catch (error) {
            this.showNotification('Connection error: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    async emergencyStop() {
        if (!confirm('Are you sure you want to perform an emergency stop? This will stop all trading and attempt to collect funds.')) {
            return;
        }
        
        this.showLoading();
        
        try {
            const response = await fetch('/api/stop', { method: 'POST' });
            const result = await response.json();
            
            if (response.ok) {
                this.botRunning = false;
                this.updateBotStatus();
                this.showNotification('Emergency stop executed successfully', 'warning');
            } else {
                this.showNotification(result.error || 'Emergency stop failed', 'error');
            }
        } catch (error) {
            this.showNotification('Emergency stop failed: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    startDataUpdates() {
        this.updateData();
        this.updateInterval = setInterval(() => {
            this.updateData();
        }, 5000); // Update every 5 seconds
    }

    async updateData() {
        try {
            const response = await fetch('/api/status');
            const data = await response.json();
            
            if (response.ok) {
                this.isConnected = true;
                this.botRunning = data.isRunning;
                this.updateUI(data);
            } else {
                this.isConnected = false;
            }
        } catch (error) {
            this.isConnected = false;
            console.error('Failed to update data:', error);
        }
        
        this.updateConnectionStatus();
    }

    updateUI(data) {
        // Update status cards
        document.getElementById('total-volume').textContent = '$' + (data.stats.totalVolume || 0).toLocaleString();
        document.getElementById('total-transactions').textContent = (data.stats.transactionCount || 0).toLocaleString();
        document.getElementById('success-rate').textContent = ((data.stats.successRate || 0) * 100).toFixed(1) + '%';
        
        // Update wallet stats
        if (data.stats.walletStats) {
            document.getElementById('active-wallets').textContent = data.stats.walletStats.activeWallets || 0;
            document.getElementById('total-balance').textContent = (data.stats.walletStats.totalBalance || 0).toFixed(4) + ' SOL';
            
            // Update wallet chart
            this.charts.wallet.data.datasets[0].data = [
                data.stats.walletStats.activeWallets || 0,
                data.stats.walletStats.inactiveWallets || 0
            ];
            this.charts.wallet.update();
        }
        
        // Update configuration display
        if (data.config) {
            document.getElementById('token-address').textContent = data.config.tokenAddress || 'Not configured';
            document.getElementById('trade-ratio').textContent = 
                `${((data.config.buyRatio || 0.7) * 100).toFixed(0)}% / ${((data.config.sellRatio || 0.3) * 100).toFixed(0)}%`;
            document.getElementById('network-env').textContent = data.config.network || 'mainnet-beta';
        }
        
        // Update system uptime
        if (data.stats.system && data.stats.system.uptime) {
            document.getElementById('system-uptime').textContent = this.formatUptime(data.stats.system.uptime);
        }
        
        this.updateBotStatus();
    }

    updateBotStatus() {
        const statusElement = document.getElementById('bot-status');
        const toggleButton = document.getElementById('toggle-bot');
        const toggleIcon = toggleButton.querySelector('i');
        
        if (this.botRunning) {
            statusElement.innerHTML = '<span class="badge bg-success">Running</span>';
            toggleButton.className = 'btn btn-warning btn-sm';
            toggleButton.innerHTML = '<i data-feather="pause"></i> Stop Bot';
        } else {
            statusElement.innerHTML = '<span class="badge bg-secondary">Stopped</span>';
            toggleButton.className = 'btn btn-success btn-sm';
            toggleButton.innerHTML = '<i data-feather="play"></i> Start Bot';
        }
        
        feather.replace();
    }

    updateConnectionStatus() {
        const statusElement = document.getElementById('connection-status');
        
        if (this.isConnected) {
            statusElement.innerHTML = '<i data-feather="wifi"></i> Connected';
            statusElement.className = 'badge bg-success me-3';
        } else {
            statusElement.innerHTML = '<i data-feather="wifi-off"></i> Disconnected';
            statusElement.className = 'badge bg-danger me-3';
        }
        
        feather.replace();
    }

    async updateVolumeChart(timeframe = '1h') {
        try {
            const response = await fetch(`/api/volume-history?timeframe=${timeframe}`);
            const data = await response.json();
            
            if (response.ok && data.history) {
                const labels = data.history.map(point => new Date(point.timestamp));
                const values = data.history.map(point => point.volume);
                
                this.charts.volume.data.labels = labels;
                this.charts.volume.data.datasets[0].data = values;
                this.charts.volume.update();
            }
        } catch (error) {
            console.error('Failed to update volume chart:', error);
        }
    }

    addTradeToList(trade) {
        const container = document.getElementById('trades-container');
        
        // Remove empty state if present
        const emptyState = container.querySelector('.text-center');
        if (emptyState) {
            container.innerHTML = '';
        }
        
        const tradeElement = document.createElement('div');
        tradeElement.className = 'trade-item d-flex justify-content-between align-items-center py-2 border-bottom';
        
        const typeClass = trade.type === 'buy' ? 'text-success' : 'text-danger';
        const typeIcon = trade.type === 'buy' ? 'arrow-up-right' : 'arrow-down-left';
        const statusIcon = trade.success ? 'check-circle' : 'x-circle';
        const statusClass = trade.success ? 'text-success' : 'text-danger';
        
        tradeElement.innerHTML = `
            <div>
                <div class="d-flex align-items-center">
                    <i data-feather="${typeIcon}" class="${typeClass} me-2"></i>
                    <strong class="text-capitalize">${trade.type}</strong>
                    <i data-feather="${statusIcon}" class="${statusClass} ms-2" style="width: 16px; height: 16px;"></i>
                </div>
                <small class="text-muted">${this.truncateAddress(trade.wallet)}</small>
            </div>
            <div class="text-end">
                <div class="fw-bold">$${(trade.volume || 0).toFixed(2)}</div>
                <small class="text-muted">${new Date(trade.timestamp).toLocaleTimeString()}</small>
            </div>
        `;
        
        container.insertBefore(tradeElement, container.firstChild);
        
        // Keep only last 50 trades
        const trades = container.querySelectorAll('.trade-item');
        if (trades.length > 50) {
            trades[trades.length - 1].remove();
        }
        
        feather.replace();
    }

    addLogEntry(log) {
        const container = document.getElementById('logs-container');
        
        // Remove empty state if present
        const emptyState = container.querySelector('.text-center');
        if (emptyState) {
            container.innerHTML = '';
        }
        
        const logElement = document.createElement('div');
        logElement.className = `log-entry py-2 border-bottom log-${log.level}`;
        
        const levelColors = {
            info: 'text-info',
            warn: 'text-warning',
            error: 'text-danger',
            debug: 'text-muted'
        };
        
        const levelIcons = {
            info: 'info',
            warn: 'alert-triangle',
            error: 'alert-circle',
            debug: 'code'
        };
        
        logElement.innerHTML = `
            <div class="d-flex align-items-start">
                <i data-feather="${levelIcons[log.level]}" class="${levelColors[log.level]} me-2 mt-1" style="width: 16px; height: 16px;"></i>
                <div class="flex-grow-1">
                    <div class="log-message">${log.message}</div>
                    <small class="text-muted">${new Date(log.timestamp).toLocaleTimeString()}</small>
                </div>
            </div>
        `;
        
        container.insertBefore(logElement, container.firstChild);
        
        // Keep only last 100 logs
        const logs = container.querySelectorAll('.log-entry');
        if (logs.length > 100) {
            logs[logs.length - 1].remove();
        }
        
        feather.replace();
    }

    filterLogs(level) {
        const logs = document.querySelectorAll('.log-entry');
        
        logs.forEach(log => {
            if (level === 'all') {
                log.style.display = 'block';
            } else {
                log.style.display = log.classList.contains(`log-${level}`) ? 'block' : 'none';
            }
        });
    }

    showLoading() {
        const modal = new bootstrap.Modal(document.getElementById('loading-modal'));
        modal.show();
    }

    hideLoading() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('loading-modal'));
        if (modal) {
            modal.hide();
        }
    }

    showNotification(message, type = 'info') {
        const alertClass = {
            success: 'alert-success',
            error: 'alert-danger',
            warning: 'alert-warning',
            info: 'alert-info'
        }[type];
        
        const notification = document.createElement('div');
        notification.className = `alert ${alertClass} alert-dismissible fade show notification`;
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Add to top of page
        document.body.insertBefore(notification, document.body.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 5000);
    }

    formatUptime(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        if (days > 0) {
            return `${days}d ${hours % 24}h`;
        } else if (hours > 0) {
            return `${hours}h ${minutes % 60}m`;
        } else if (minutes > 0) {
            return `${minutes}m ${seconds % 60}s`;
        } else {
            return `${seconds}s`;
        }
    }

    truncateAddress(address, chars = 8) {
        if (address.length <= chars * 2) {
            return address;
        }
        return `${address.slice(0, chars)}...${address.slice(-chars)}`;
    }
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new MistyDashboard();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        // Pause updates when tab is not visible
        if (window.dashboard && window.dashboard.updateInterval) {
            clearInterval(window.dashboard.updateInterval);
        }
    } else {
        // Resume updates when tab becomes visible
        if (window.dashboard) {
            window.dashboard.startDataUpdates();
        }
    }
});
