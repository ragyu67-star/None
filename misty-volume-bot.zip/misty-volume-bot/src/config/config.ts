import dotenv from 'dotenv';

dotenv.config();

export const config = {
    // Wallet Configuration
    PRIVATE_KEY: process.env['PRIVATE_KEY'] || '',
    RPC_ENDPOINT: process.env['RPC_ENDPOINT'] || 'https://api.mainnet-beta.solana.com',
    NETWORK: process.env['NETWORK'] || 'mainnet-beta',
    
    // Token Configuration
    TOKEN_ADDRESS: process.env['TOKEN_ADDRESS'] || '',
    
    // Trading Configuration
    WALLET_COUNT: parseInt(process.env['WALLET_COUNT'] || '8'),
    DISTRIBUTION_AMOUNT: parseFloat(process.env['DISTRIBUTION_AMOUNT'] || '0.01'), // SOL per wallet
    BUY_RATIO: parseFloat(process.env['BUY_RATIO'] || '0.7'),
    SELL_RATIO: parseFloat(process.env['SELL_RATIO'] || '0.3'),
    
    // Timing Configuration
    MIN_INTERVAL: parseInt(process.env['MIN_INTERVAL'] || '3000'), // 3 seconds
    MAX_INTERVAL: parseInt(process.env['MAX_INTERVAL'] || '10000'), // 10 seconds
    
    // Transaction Configuration
    SLIPPAGE_BPS: parseInt(process.env['SLIPPAGE_BPS'] || '300'), // 3%
    MAX_RETRIES: parseInt(process.env['MAX_RETRIES'] || '3'),
    
    // Risk Management
    MIN_BALANCE_THRESHOLD: parseFloat(process.env['MIN_BALANCE_THRESHOLD'] || '0.005'), // 0.005 SOL
    MAX_DAILY_VOLUME: parseFloat(process.env['MAX_DAILY_VOLUME'] || '1000000'), // 1M USD
    
    // JITO Configuration
    JITO_ENDPOINT: process.env['JITO_ENDPOINT'] || 'https://mainnet.block-engine.jito.wtf/api/v1',
    JITO_TIP_AMOUNT: parseInt(process.env['JITO_TIP_AMOUNT'] || '1000'), // lamports
    
    // Monitoring
    LOG_LEVEL: process.env['LOG_LEVEL'] || 'info',
    ENABLE_DASHBOARD: process.env['ENABLE_DASHBOARD'] !== 'false',
    
    // Raydium Configuration
    RAYDIUM_PROGRAM_ID: 'CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK',
    RAYDIUM_AUTHORITY: '5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1',
};

// Validation
if (!config.PRIVATE_KEY) {
    throw new Error('PRIVATE_KEY environment variable is required');
}

if (!config.TOKEN_ADDRESS) {
    throw new Error('TOKEN_ADDRESS environment variable is required');
}

if (config.BUY_RATIO + config.SELL_RATIO !== 1.0) {
    throw new Error('BUY_RATIO + SELL_RATIO must equal 1.0');
}
