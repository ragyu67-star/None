import { Connection, Keypair, PublicKey, SystemProgram, Transaction, sendAndConfirmTransaction } from '@solana/web3.js';
import { config } from '../config/config';
import { logger } from '../utils/logger';
import { sleep, getRandomDelay } from '../utils/helpers';

export interface WalletInfo {
    keypair: Keypair;
    publicKey: PublicKey;
    balance: number;
    isActive: boolean;
}

export class WalletManager {
    private connection: Connection;
    private masterWallet: Keypair;
    private subWallets: WalletInfo[] = [];
    private initialized = false;

    constructor() {
        this.connection = new Connection(config.RPC_ENDPOINT, 'confirmed');
        this.masterWallet = Keypair.fromSecretKey(
            Buffer.from(config.PRIVATE_KEY.split(',').map(x => parseInt(x)))
        );
    }

    public async initialize(): Promise<void> {
        if (this.initialized) {
            return;
        }

        logger.info('🔑 Initializing Wallet Manager...');
        
        // Check master wallet balance
        const masterBalance = await this.getMasterBalance();
        logger.info(`💰 Master wallet balance: ${masterBalance} SOL`);
        
        const requiredBalance = config.WALLET_COUNT * config.DISTRIBUTION_AMOUNT + 0.1; // Extra for fees
        if (masterBalance < requiredBalance) {
            throw new Error(`Insufficient balance. Required: ${requiredBalance} SOL, Available: ${masterBalance} SOL`);
        }

        // Generate sub-wallets
        await this.generateSubWallets();
        
        // Distribute SOL to sub-wallets
        await this.distributeSOL();
        
        this.initialized = true;
        logger.info('✅ Wallet Manager initialized successfully');
    }

    private async generateSubWallets(): Promise<void> {
        logger.info(`🔄 Generating ${config.WALLET_COUNT} sub-wallets...`);
        
        for (let i = 0; i < config.WALLET_COUNT; i++) {
            const keypair = Keypair.generate();
            this.subWallets.push({
                keypair,
                publicKey: keypair.publicKey,
                balance: 0,
                isActive: true
            });
        }
        
        logger.info(`✅ Generated ${this.subWallets.length} sub-wallets`);
    }

    private async distributeSOL(): Promise<void> {
        logger.info('💸 Distributing SOL to sub-wallets...');
        
        const instructions = this.subWallets.map(wallet => 
            SystemProgram.transfer({
                fromPubkey: this.masterWallet.publicKey,
                toPubkey: wallet.publicKey,
                lamports: config.DISTRIBUTION_AMOUNT * 1e9 // Convert to lamports
            })
        );

        // Split into batches to avoid transaction size limits
        const batchSize = 5;
        for (let i = 0; i < instructions.length; i += batchSize) {
            const batch = instructions.slice(i, i + batchSize);
            
            try {
                const transaction = new Transaction().add(...batch);
                const signature = await sendAndConfirmTransaction(
                    this.connection,
                    transaction,
                    [this.masterWallet],
                    { commitment: 'confirmed' }
                );
                
                logger.info(`📄 Distribution batch ${Math.floor(i/batchSize) + 1} confirmed: ${signature}`);
                
                // Update balances for this batch
                for (let j = i; j < Math.min(i + batchSize, this.subWallets.length); j++) {
                    this.subWallets[j].balance = config.DISTRIBUTION_AMOUNT;
                }
                
                // Small delay between batches
                if (i + batchSize < instructions.length) {
                    await sleep(getRandomDelay(1000, 2000));
                }
                
            } catch (error) {
                logger.error(`❌ Failed to distribute to batch ${Math.floor(i/batchSize) + 1}:`, error);
                throw error;
            }
        }
        
        logger.info('✅ SOL distribution completed');
    }

    public async getMasterBalance(): Promise<number> {
        const balance = await this.connection.getBalance(this.masterWallet.publicKey);
        return balance / 1e9; // Convert lamports to SOL
    }

    public async updateWalletBalances(): Promise<void> {
        const promises = this.subWallets.map(async (wallet) => {
            try {
                const balance = await this.connection.getBalance(wallet.publicKey);
                wallet.balance = balance / 1e9;
                
                // Deactivate wallets with insufficient balance
                if (wallet.balance < config.MIN_BALANCE_THRESHOLD) {
                    wallet.isActive = false;
                    logger.warn(`⚠️  Wallet ${wallet.publicKey.toString().slice(0, 8)}... deactivated (low balance: ${wallet.balance} SOL)`);
                }
            } catch (error) {
                logger.error(`Failed to update balance for wallet ${wallet.publicKey.toString()}:`, error);
            }
        });
        
        await Promise.all(promises);
    }

    public getActiveWallets(): WalletInfo[] {
        return this.subWallets.filter(wallet => wallet.isActive);
    }

    public getAllWallets(): WalletInfo[] {
        return this.subWallets;
    }

    public getMasterWallet(): Keypair {
        return this.masterWallet;
    }

    public getWalletStats() {
        const totalWallets = this.subWallets.length;
        const activeWallets = this.getActiveWallets().length;
        const totalBalance = this.subWallets.reduce((sum, wallet) => sum + wallet.balance, 0);
        
        return {
            totalWallets,
            activeWallets,
            inactiveWallets: totalWallets - activeWallets,
            totalBalance,
            averageBalance: totalWallets > 0 ? totalBalance / totalWallets : 0
        };
    }

    public async redistributeSOL(): Promise<void> {
        logger.info('🔄 Redistributing SOL to low-balance wallets...');
        
        const lowBalanceWallets = this.subWallets.filter(
            wallet => wallet.balance < config.MIN_BALANCE_THRESHOLD && wallet.balance > 0
        );
        
        if (lowBalanceWallets.length === 0) {
            logger.info('No wallets need redistribution');
            return;
        }
        
        const masterBalance = await this.getMasterBalance();
        const requiredAmount = lowBalanceWallets.length * config.DISTRIBUTION_AMOUNT;
        
        if (masterBalance < requiredAmount) {
            logger.warn(`Insufficient master balance for redistribution. Required: ${requiredAmount}, Available: ${masterBalance}`);
            return;
        }
        
        // Redistribute to low-balance wallets
        const instructions = lowBalanceWallets.map(wallet =>
            SystemProgram.transfer({
                fromPubkey: this.masterWallet.publicKey,
                toPubkey: wallet.publicKey,
                lamports: config.DISTRIBUTION_AMOUNT * 1e9
            })
        );
        
        const transaction = new Transaction().add(...instructions);
        const signature = await sendAndConfirmTransaction(
            this.connection,
            transaction,
            [this.masterWallet],
            { commitment: 'confirmed' }
        );
        
        // Update wallet balances and reactivate
        lowBalanceWallets.forEach(wallet => {
            wallet.balance += config.DISTRIBUTION_AMOUNT;
            wallet.isActive = true;
        });
        
        logger.info(`✅ Redistributed SOL to ${lowBalanceWallets.length} wallets: ${signature}`);
    }
}
