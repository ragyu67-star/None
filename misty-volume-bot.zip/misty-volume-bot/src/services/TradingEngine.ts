import { Connection, PublicKey, Transaction, SystemProgram } from '@solana/web3.js';
import { config } from '../config/config';
import { WalletManager, WalletInfo } from './WalletManager';
import { JitoService } from './JitoService';
import { logger } from '../utils/logger';
import { sleep, getRandomDelay, getRandomAmount } from '../utils/helpers';

export interface TradeResult {
    success: boolean;
    signature?: string;
    error?: string;
    volume?: number;
    type: 'buy' | 'sell';
    wallet: string;
    timestamp: number;
}

export class TradingEngine {
    private connection: Connection;
    private walletManager: WalletManager;
    private jitoService: JitoService;
    private isRunning = false;
    private tradeCount = 0;
    private totalVolume = 0;
    private intervalId?: NodeJS.Timer;

    constructor(walletManager: WalletManager) {
        this.connection = new Connection(config.RPC_ENDPOINT, 'confirmed');
        this.walletManager = walletManager;
        this.jitoService = new JitoService();
    }

    public async start(): Promise<void> {
        if (this.isRunning) {
            throw new Error('Trading engine is already running');
        }

        logger.info('🔥 Starting Trading Engine...');
        
        // Initialize JITO service
        await this.jitoService.initialize();
        
        this.isRunning = true;
        this.scheduleNextTrade();
        
        logger.info('✅ Trading Engine started successfully');
    }

    public async stop(): Promise<void> {
        if (!this.isRunning) {
            return;
        }

        logger.info('🛑 Stopping Trading Engine...');
        
        this.isRunning = false;
        if (this.intervalId) {
            clearTimeout(this.intervalId);
        }
        
        logger.info('✅ Trading Engine stopped');
    }

    private scheduleNextTrade(): void {
        if (!this.isRunning) {
            return;
        }

        const delay = getRandomDelay(config.MIN_INTERVAL, config.MAX_INTERVAL);
        
        this.intervalId = setTimeout(async () => {
            try {
                await this.executeTrade();
                this.scheduleNextTrade();
            } catch (error) {
                logger.error('Trade execution failed:', error);
                
                // Wait longer before next attempt on error
                setTimeout(() => this.scheduleNextTrade(), delay * 2);
            }
        }, delay);
    }

    private async executeTrade(): Promise<TradeResult> {
        // Update wallet balances before trading
        await this.walletManager.updateWalletBalances();
        
        const activeWallets = this.walletManager.getActiveWallets();
        if (activeWallets.length === 0) {
            logger.warn('⚠️  No active wallets available for trading');
            throw new Error('No active wallets available');
        }

        // Select random wallet
        const wallet = activeWallets[Math.floor(Math.random() * activeWallets.length)];
        
        // Determine trade type based on configured ratio
        const isBuy = Math.random() < config.BUY_RATIO;
        const tradeType = isBuy ? 'buy' : 'sell';
        
        logger.info(`📈 Executing ${tradeType} trade with wallet ${wallet.publicKey.toString().slice(0, 8)}...`);
        
        try {
            const result = await this.executeSwap(wallet, tradeType);
            
            this.tradeCount++;
            if (result.volume) {
                this.totalVolume += result.volume;
            }
            
            logger.info(`✅ ${tradeType} trade completed: ${result.signature?.slice(0, 8)}... | Volume: $${result.volume?.toFixed(2) || 0}`);
            
            return result;
            
        } catch (error) {
            logger.error(`❌ ${tradeType} trade failed:`, error);
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error',
                type: tradeType,
                wallet: wallet.publicKey.toString(),
                timestamp: Date.now()
            };
        }
    }

    private async executeSwap(wallet: WalletInfo, tradeType: 'buy' | 'sell'): Promise<TradeResult> {
        // This is a simplified swap implementation
        // In a real implementation, you would use Raydium SDK or Jupiter API
        
        const tradeAmount = getRandomAmount(0.001, Math.min(wallet.balance * 0.8, 0.05)); // Max 5% of wallet or 80% of balance
        const estimatedVolume = tradeAmount * 200; // Rough SOL price estimate for volume calculation
        
        try {
            // Simulate the swap transaction
            // In practice, this would be a complex transaction involving:
            // 1. Token account creation if needed
            // 2. Swap instruction to Raydium
            // 3. Proper slippage handling
            
            const mockTransaction = new Transaction().add(
                SystemProgram.transfer({
                    fromPubkey: wallet.publicKey,
                    toPubkey: wallet.publicKey, // Self-transfer as mock
                    lamports: 1000 // Minimal amount for demo
                })
            );
            
            // Use JITO for bundled transactions
            const signature = await this.jitoService.sendBundle([
                {
                    transaction: mockTransaction,
                    keypair: wallet.keypair
                }
            ]);
            
            // Update wallet balance (simplified)
            if (tradeType === 'buy') {
                wallet.balance -= tradeAmount;
            } else {
                wallet.balance += tradeAmount * 0.97; // Account for slippage
            }
            
            return {
                success: true,
                signature,
                volume: estimatedVolume,
                type: tradeType,
                wallet: wallet.publicKey.toString(),
                timestamp: Date.now()
            };
            
        } catch (error) {
            throw new Error(`Swap execution failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }

    public getStats() {
        return {
            isRunning: this.isRunning,
            tradeCount: this.tradeCount,
            totalVolume: this.totalVolume,
            averageVolume: this.tradeCount > 0 ? this.totalVolume / this.tradeCount : 0,
            walletStats: this.walletManager.getWalletStats()
        };
    }

    public async emergencyStop(): Promise<void> {
        logger.warn('🚨 Emergency stop triggered!');
        await this.stop();
        
        // Attempt to collect funds back to master wallet
        try {
            await this.collectFunds();
        } catch (error) {
            logger.error('Failed to collect funds during emergency stop:', error);
        }
    }

    private async collectFunds(): Promise<void> {
        logger.info('💰 Collecting funds back to master wallet...');
        
        const activeWallets = this.walletManager.getActiveWallets();
        const masterWallet = this.walletManager.getMasterWallet();
        
        const transactions = activeWallets
            .filter(wallet => wallet.balance > 0.001) // Only collect if balance > 0.001 SOL
            .map(wallet => {
                const lamports = Math.floor(wallet.balance * 1e9 - 5000); // Leave 5000 lamports for fees
                return new Transaction().add(
                    SystemProgram.transfer({
                        fromPubkey: wallet.publicKey,
                        toPubkey: masterWallet.publicKey,
                        lamports: Math.max(0, lamports)
                    })
                );
            });
        
        if (transactions.length === 0) {
            logger.info('No funds to collect');
            return;
        }
        
        // Execute fund collection
        const bundleItems = transactions.map((tx, index) => ({
            transaction: tx,
            keypair: activeWallets[index].keypair
        }));
        
        try {
            const signature = await this.jitoService.sendBundle(bundleItems);
            logger.info(`✅ Funds collected successfully: ${signature}`);
        } catch (error) {
            logger.error('Failed to collect funds:', error);
        }
    }
}
