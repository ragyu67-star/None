import { Connection, Transaction, Keypair, VersionedTransaction, TransactionMessage } from '@solana/web3.js';
import { config } from '../config/config';
import { logger } from '../utils/logger';
import axios from 'axios';

export interface BundleItem {
    transaction: Transaction;
    keypair: Keypair;
}

export class JitoService {
    private connection: Connection;
    private jitoEndpoint: string;
    private initialized = false;

    constructor() {
        this.connection = new Connection(config.RPC_ENDPOINT, 'confirmed');
        this.jitoEndpoint = config.JITO_ENDPOINT;
    }

    public async initialize(): Promise<void> {
        if (this.initialized) {
            return;
        }

        logger.info('⚡ Initializing JITO Service...');
        
        try {
            // Test JITO endpoint connectivity
            await this.testConnection();
            this.initialized = true;
            logger.info('✅ JITO Service initialized successfully');
        } catch (error) {
            logger.warn('⚠️  JITO Service initialization failed, falling back to regular RPC:', error);
            this.initialized = true; // Continue without JITO
        }
    }

    private async testConnection(): Promise<void> {
        try {
            const response = await axios.get(`${this.jitoEndpoint}/bundles`, {
                timeout: 5000
            });
            
            if (response.status !== 200) {
                throw new Error(`JITO endpoint returned status: ${response.status}`);
            }
        } catch (error) {
            throw new Error(`Failed to connect to JITO endpoint: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }

    public async sendBundle(items: BundleItem[]): Promise<string> {
        if (!this.initialized) {
            throw new Error('JITO Service not initialized');
        }

        try {
            // If JITO is not available, fall back to regular transaction sending
            if (!await this.isJitoAvailable()) {
                return await this.sendRegularTransactions(items);
            }

            logger.info(`📦 Sending bundle with ${items.length} transactions...`);
            
            // Get recent blockhash
            const { blockhash } = await this.connection.getRecentBlockhash();
            
            // Sign all transactions
            const signedTransactions: VersionedTransaction[] = [];
            
            for (const item of items) {
                item.transaction.recentBlockhash = blockhash;
                item.transaction.feePayer = item.keypair.publicKey;
                
                // Sign transaction
                item.transaction.sign(item.keypair);
                
                // Convert to VersionedTransaction
                const message = TransactionMessage.decompile(item.transaction);
                const versionedTx = new VersionedTransaction(message);
                
                signedTransactions.push(versionedTx);
            }
            
            // Send bundle to JITO
            const bundleId = await this.submitBundle(signedTransactions);
            
            logger.info(`✅ Bundle submitted successfully: ${bundleId}`);
            return bundleId;
            
        } catch (error) {
            logger.warn('JITO bundle failed, falling back to regular transactions:', error);
            return await this.sendRegularTransactions(items);
        }
    }

    private async submitBundle(transactions: VersionedTransaction[]): Promise<string> {
        const bundleData = {
            jsonrpc: "2.0",
            id: 1,
            method: "sendBundle",
            params: [
                transactions.map(tx => Buffer.from(tx.serialize()).toString('base64'))
            ]
        };

        try {
            const response = await axios.post(this.jitoEndpoint, bundleData, {
                headers: {
                    'Content-Type': 'application/json'
                },
                timeout: 10000
            });

            if (response.data.error) {
                throw new Error(`JITO API error: ${response.data.error.message}`);
            }

            return response.data.result;
        } catch (error) {
            if (axios.isAxiosError(error)) {
                throw new Error(`JITO request failed: ${error.message}`);
            }
            throw error;
        }
    }

    private async sendRegularTransactions(items: BundleItem[]): Promise<string> {
        logger.info(`📤 Sending ${items.length} regular transactions...`);
        
        const signatures: string[] = [];
        
        for (const item of items) {
            try {
                const signature = await this.connection.sendTransaction(
                    item.transaction,
                    [item.keypair],
                    {
                        skipPreflight: false,
                        preflightCommitment: 'processed',
                        maxRetries: config.MAX_RETRIES
                    }
                );
                
                signatures.push(signature);
                
                // Small delay between transactions
                await new Promise(resolve => setTimeout(resolve, 100));
                
            } catch (error) {
                logger.error('Regular transaction failed:', error);
                continue;
            }
        }
        
        if (signatures.length === 0) {
            throw new Error('All transactions failed');
        }
        
        logger.info(`✅ Sent ${signatures.length}/${items.length} transactions successfully`);
        return signatures[0]; // Return first signature as bundle ID
    }

    private async isJitoAvailable(): Promise<boolean> {
        try {
            const response = await axios.get(`${this.jitoEndpoint}/bundles`, {
                timeout: 2000
            });
            return response.status === 200;
        } catch {
            return false;
        }
    }

    public async getTipAccounts(): Promise<string[]> {
        try {
            const response = await axios.post(this.jitoEndpoint, {
                jsonrpc: "2.0",
                id: 1,
                method: "getTipAccounts"
            });
            
            return response.data.result || [];
        } catch (error) {
            logger.warn('Failed to get tip accounts:', error);
            return [];
        }
    }

    public getStatus() {
        return {
            initialized: this.initialized,
            endpoint: this.jitoEndpoint,
            available: this.isJitoAvailable()
        };
    }
}
