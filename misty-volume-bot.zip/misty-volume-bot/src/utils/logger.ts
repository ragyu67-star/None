import winston from 'winston';
import { config } from '../config/config';

// Define log levels and colors
const logLevels = {
    error: 0,
    warn: 1,
    info: 2,
    debug: 3,
};

const logColors = {
    error: 'red',
    warn: 'yellow',
    info: 'green',
    debug: 'blue',
};

// Create winston logger
export const logger = winston.createLogger({
    levels: logLevels,
    level: config.LOG_LEVEL,
    format: winston.format.combine(
        winston.format.timestamp({
            format: 'YYYY-MM-DD HH:mm:ss'
        }),
        winston.format.errors({ stack: true }),
        winston.format.colorize(),
        winston.format.printf(({ timestamp, level, message, stack }) => {
            const logMessage = `${timestamp} [${level}]: ${message}`;
            return stack ? `${logMessage}\n${stack}` : logMessage;
        })
    ),
    transports: [
        // Console transport
        new winston.transports.Console({
            handleExceptions: true,
            handleRejections: true,
        }),
        
        // File transport for errors
        new winston.transports.File({
            filename: 'logs/error.log',
            level: 'error',
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.errors({ stack: true }),
                winston.format.json()
            ),
            maxsize: 10485760, // 10MB
            maxFiles: 5,
        }),
        
        // File transport for all logs
        new winston.transports.File({
            filename: 'logs/combined.log',
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.errors({ stack: true }),
                winston.format.json()
            ),
            maxsize: 10485760, // 10MB
            maxFiles: 10,
        })
    ],
    exitOnError: false,
});

// Add colors to winston
winston.addColors(logColors);

// Create logs directory if it doesn't exist
import fs from 'fs';
import path from 'path';

const logsDir = path.join(process.cwd(), 'logs');
if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
}

// Export logging functions for convenience
export const logInfo = (message: string, meta?: any) => logger.info(message, meta);
export const logWarn = (message: string, meta?: any) => logger.warn(message, meta);
export const logError = (message: string, error?: any) => {
    if (error instanceof Error) {
        logger.error(message, { error: error.message, stack: error.stack });
    } else if (error) {
        logger.error(message, { error });
    } else {
        logger.error(message);
    }
};
export const logDebug = (message: string, meta?: any) => logger.debug(message, meta);

// Performance logging
export const logPerformance = (operation: string, startTime: number) => {
    const duration = Date.now() - startTime;
    logger.info(`⏱️  ${operation} completed in ${duration}ms`);
};

// Transaction logging
export const logTransaction = (type: 'buy' | 'sell', signature: string, volume: number, success: boolean) => {
    const emoji = success ? '✅' : '❌';
    const status = success ? 'SUCCESS' : 'FAILED';
    logger.info(`${emoji} ${type.toUpperCase()} ${status}: ${signature.slice(0, 8)}... | Volume: $${volume.toFixed(2)}`);
};

// Wallet logging
export const logWallet = (action: string, publicKey: string, balance: number) => {
    logger.info(`💰 ${action}: ${publicKey.slice(0, 8)}... | Balance: ${balance.toFixed(4)} SOL`);
};

// System status logging
export const logSystemStatus = (component: string, status: 'ONLINE' | 'OFFLINE' | 'ERROR', message?: string) => {
    const emoji = status === 'ONLINE' ? '✅' : status === 'ERROR' ? '❌' : '⚠️';
    const logMessage = `${emoji} ${component}: ${status}${message ? ` - ${message}` : ''}`;
    
    if (status === 'ERROR') {
        logger.error(logMessage);
    } else if (status === 'OFFLINE') {
        logger.warn(logMessage);
    } else {
        logger.info(logMessage);
    }
};
