import { PublicKey } from '@solana/web3.js';

/**
 * Sleep for a specified number of milliseconds
 */
export const sleep = (ms: number): Promise<void> => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Generate a random delay between min and max milliseconds
 */
export const getRandomDelay = (min: number, max: number): number => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

/**
 * Generate a random amount between min and max
 */
export const getRandomAmount = (min: number, max: number): number => {
    return Math.random() * (max - min) + min;
};

/**
 * Format SOL amount with proper decimals
 */
export const formatSOL = (amount: number): string => {
    return amount.toFixed(4) + ' SOL';
};

/**
 * Format USD amount with proper formatting
 */
export const formatUSD = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
};

/**
 * Format large numbers with K, M, B suffixes
 */
export const formatLargeNumber = (num: number): string => {
    if (num >= 1e9) {
        return (num / 1e9).toFixed(1) + 'B';
    }
    if (num >= 1e6) {
        return (num / 1e6).toFixed(1) + 'M';
    }
    if (num >= 1e3) {
        return (num / 1e3).toFixed(1) + 'K';
    }
    return num.toFixed(2);
};

/**
 * Validate Solana public key
 */
export const isValidPublicKey = (key: string): boolean => {
    try {
        new PublicKey(key);
        return true;
    } catch {
        return false;
    }
};

/**
 * Truncate public key for display
 */
export const truncatePublicKey = (key: string, chars: number = 8): string => {
    if (key.length <= chars * 2) {
        return key;
    }
    return `${key.slice(0, chars)}...${key.slice(-chars)}`;
};

/**
 * Convert lamports to SOL
 */
export const lamportsToSOL = (lamports: number): number => {
    return lamports / 1e9;
};

/**
 * Convert SOL to lamports
 */
export const solToLamports = (sol: number): number => {
    return Math.floor(sol * 1e9);
};

/**
 * Generate a random boolean with specified probability
 */
export const randomBool = (probability: number = 0.5): boolean => {
    return Math.random() < probability;
};

/**
 * Calculate percentage change
 */
export const percentageChange = (oldValue: number, newValue: number): number => {
    if (oldValue === 0) return 0;
    return ((newValue - oldValue) / oldValue) * 100;
};

/**
 * Format uptime in human-readable format
 */
export const formatUptime = (milliseconds: number): string => {
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) {
        return `${days}d ${hours % 24}h ${minutes % 60}m`;
    } else if (hours > 0) {
        return `${hours}h ${minutes % 60}m`;
    } else if (minutes > 0) {
        return `${minutes}m ${seconds % 60}s`;
    } else {
        return `${seconds}s`;
    }
};

/**
 * Generate a random string of specified length
 */
export const randomString = (length: number): string => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
};

/**
 * Retry a function with exponential backoff
 */
export const retryWithBackoff = async <T>(
    fn: () => Promise<T>,
    maxRetries: number = 3,
    baseDelay: number = 1000
): Promise<T> => {
    let lastError: Error;
    
    for (let attempt = 0; attempt < maxRetries; attempt++) {
        try {
            return await fn();
        } catch (error) {
            lastError = error instanceof Error ? error : new Error('Unknown error');
            
            if (attempt === maxRetries - 1) {
                throw lastError;
            }
            
            const delay = baseDelay * Math.pow(2, attempt);
            await sleep(delay + Math.random() * 1000); // Add jitter
        }
    }
    
    throw lastError!;
};

/**
 * Chunk array into smaller arrays
 */
export const chunkArray = <T>(array: T[], chunkSize: number): T[][] => {
    const chunks: T[][] = [];
    for (let i = 0; i < array.length; i += chunkSize) {
        chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
};

/**
 * Deep clone an object
 */
export const deepClone = <T>(obj: T): T => {
    return JSON.parse(JSON.stringify(obj));
};

/**
 * Check if running in production environment
 */
export const isProduction = (): boolean => {
    return process.env.NODE_ENV === 'production';
};

/**
 * Get current timestamp in ISO format
 */
export const getCurrentTimestamp = (): string => {
    return new Date().toISOString();
};

/**
 * Sanitize string for logging (remove sensitive data)
 */
export const sanitizeForLog = (str: string): string => {
    // Remove potential private keys, addresses, etc.
    return str.replace(/[0-9A-Za-z]{32,}/g, '***REDACTED***');
};

/**
 * Calculate success rate percentage
 */
export const calculateSuccessRate = (successful: number, total: number): number => {
    if (total === 0) return 0;
    return (successful / total) * 100;
};

/**
 * Generate weighted random choice
 */
export const weightedRandom = <T>(items: T[], weights: number[]): T => {
    if (items.length !== weights.length) {
        throw new Error('Items and weights arrays must have the same length');
    }
    
    const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
    let randomWeight = Math.random() * totalWeight;
    
    for (let i = 0; i < items.length; i++) {
        randomWeight -= weights[i];
        if (randomWeight <= 0) {
            return items[i];
        }
    }
    
    return items[items.length - 1];
};
