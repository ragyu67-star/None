// Trading Types
export interface TradeConfig {
    tokenAddress: string;
    buyRatio: number;
    sellRatio: number;
    minInterval: number;
    maxInterval: number;
    slippageBps: number;
    maxRetries: number;
}

export interface TradeResult {
    success: boolean;
    signature?: string;
    error?: string;
    volume?: number;
    type: 'buy' | 'sell';
    wallet: string;
    timestamp: number;
    gasUsed?: number;
    slippage?: number;
}

export interface SwapParams {
    tokenIn: string;
    tokenOut: string;
    amount: number;
    slippageBps: number;
    wallet: string;
}

// Wallet Types
export interface WalletInfo {
    keypair: import('@solana/web3.js').Keypair;
    publicKey: import('@solana/web3.js').PublicKey;
    balance: number;
    tokenBalance?: number;
    isActive: boolean;
    lastUsed?: number;
    totalTrades?: number;
}

export interface WalletStats {
    totalWallets: number;
    activeWallets: number;
    inactiveWallets: number;
    totalBalance: number;
    averageBalance: number;
    totalTokenBalance?: number;
}

// Monitoring Types
export interface VolumeStats {
    totalVolume: number;
    dailyVolume: number;
    hourlyVolume: number;
    transactionCount: number;
    successfulTransactions: number;
    failedTransactions: number;
    successRate: number;
    averageTransactionValue: number;
    peakHourlyVolume: number;
    peakDailyVolume: number;
}

export interface SystemStats {
    uptime: number;
    memoryUsage: NodeJS.MemoryUsage;
    cpuUsage?: number;
    activeConnections: number;
    rpcLatency?: number;
    jitoStatus: boolean;
}

export interface LogEntry {
    timestamp: number;
    level: 'info' | 'warn' | 'error' | 'debug';
    message: string;
    component?: string;
    data?: any;
    wallet?: string;
    signature?: string;
}

export interface Alert {
    id: string;
    type: AlertType;
    message: string;
    severity: 'info' | 'warning' | 'error' | 'critical';
    timestamp: number;
    acknowledged: boolean;
    data?: any;
}

export type AlertType = 
    | 'high_memory_usage'
    | 'low_success_rate'
    | 'wallet_low_balance'
    | 'daily_volume_limit'
    | 'rpc_connection_error'
    | 'jito_service_down'
    | 'trading_engine_error'
    | 'emergency_stop';

// Configuration Types
export interface BotConfig {
    // Network settings
    rpcEndpoint: string;
    network: 'mainnet-beta' | 'devnet' | 'testnet';
    
    // Wallet settings
    privateKey: string;
    walletCount: number;
    distributionAmount: number;
    minBalanceThreshold: number;
    
    // Trading settings
    tokenAddress: string;
    buyRatio: number;
    sellRatio: number;
    minInterval: number;
    maxInterval: number;
    slippageBps: number;
    maxRetries: number;
    
    // Risk management
    maxDailyVolume: number;
    emergencyStopThreshold: number;
    
    // JITO settings
    jitoEndpoint: string;
    jitoTipAmount: number;
    
    // Monitoring settings
    logLevel: string;
    enableDashboard: boolean;
    webhookUrl?: string;
}

// API Types
export interface ApiResponse<T = any> {
    success: boolean;
    data?: T;
    error?: string;
    timestamp: number;
}

export interface DashboardData {
    status: {
        isRunning: boolean;
        uptime: number;
        lastUpdate: number;
    };
    stats: VolumeStats;
    system: SystemStats;
    wallets: WalletStats;
    recentTrades: TradeResult[];
    recentLogs: LogEntry[];
    alerts: Alert[];
    config: Partial<BotConfig>;
}

// JITO Types
export interface JitoBundle {
    transactions: string[];
    tipAmount: number;
    tipAccount: string;
}

export interface JitoBundleResult {
    bundleId: string;
    transactions: string[];
    landedSlot?: number;
    status: 'pending' | 'landed' | 'failed' | 'dropped';
}

export interface BundleItem {
    transaction: import('@solana/web3.js').Transaction;
    keypair: import('@solana/web3.js').Keypair;
}

// DEX Types
export interface PoolInfo {
    address: string;
    tokenA: string;
    tokenB: string;
    liquidity: number;
    volume24h: number;
    fee: number;
}

export interface TokenInfo {
    address: string;
    symbol: string;
    name: string;
    decimals: number;
    supply: number;
    price?: number;
    marketCap?: number;
}

export interface MarketData {
    price: number;
    volume24h: number;
    liquidity: number;
    priceChange24h: number;
    transactions24h: number;
    holders: number;
}

// Event Types
export interface BotEvent {
    type: BotEventType;
    timestamp: number;
    data: any;
}

export type BotEventType =
    | 'bot_started'
    | 'bot_stopped'
    | 'trade_executed'
    | 'wallet_created'
    | 'balance_updated'
    | 'error_occurred'
    | 'alert_triggered'
    | 'config_updated';

// Utility Types
export type Prettify<T> = {
    [K in keyof T]: T[K];
} & {};

export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;

// Error Types
export interface BotError extends Error {
    code: string;
    component: string;
    recoverable: boolean;
    context?: any;
}

export interface TransactionError extends BotError {
    signature?: string;
    wallet?: string;
    operation: 'buy' | 'sell' | 'transfer';
}

export interface NetworkError extends BotError {
    endpoint: string;
    statusCode?: number;
    retryAfter?: number;
}
