import { EventEmitter } from 'events';
import { logger } from '../utils/logger';
import { config } from '../config/config';

export interface VolumeStats {
    totalVolume: number;
    dailyVolume: number;
    hourlyVolume: number;
    transactionCount: number;
    successRate: number;
    averageTransactionValue: number;
}

export interface SystemStats {
    uptime: number;
    memoryUsage: NodeJS.MemoryUsage;
    activeConnections: number;
}

export interface LogEntry {
    timestamp: number;
    level: string;
    message: string;
    data?: any;
}

export class MonitoringService extends EventEmitter {
    private startTime: number = Date.now();
    private volumeStats: VolumeStats = {
        totalVolume: 0,
        dailyVolume: 0,
        hourlyVolume: 0,
        transactionCount: 0,
        successRate: 0,
        averageTransactionValue: 0
    };
    private recentLogs: LogEntry[] = [];
    private maxLogEntries = 1000;
    private monitoringInterval?: NodeJS.Timer;
    private dailyResetInterval?: NodeJS.Timer;
    private hourlyResetInterval?: NodeJS.Timer;

    constructor() {
        super();
        this.setupLogCapture();
    }

    public start(): void {
        logger.info('📊 Starting Monitoring Service...');
        
        // Start periodic monitoring
        this.monitoringInterval = setInterval(() => {
            this.collectMetrics();
        }, 30000); // Every 30 seconds
        
        // Reset daily stats at midnight
        this.dailyResetInterval = setInterval(() => {
            this.resetDailyStats();
        }, 24 * 60 * 60 * 1000); // Every 24 hours
        
        // Reset hourly stats every hour
        this.hourlyResetInterval = setInterval(() => {
            this.resetHourlyStats();
        }, 60 * 60 * 1000); // Every hour
        
        logger.info('✅ Monitoring Service started');
    }

    public stop(): void {
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
        }
        if (this.dailyResetInterval) {
            clearInterval(this.dailyResetInterval);
        }
        if (this.hourlyResetInterval) {
            clearInterval(this.hourlyResetInterval);
        }
        
        logger.info('✅ Monitoring Service stopped');
    }

    private setupLogCapture(): void {
        // Capture logs for dashboard display
        const originalLog = logger.info;
        const originalWarn = logger.warn;
        const originalError = logger.error;
        
        logger.info = (...args: any[]) => {
            this.addLogEntry('info', args.join(' '));
            return originalLog.apply(logger, args);
        };
        
        logger.warn = (...args: any[]) => {
            this.addLogEntry('warn', args.join(' '));
            return originalWarn.apply(logger, args);
        };
        
        logger.error = (...args: any[]) => {
            this.addLogEntry('error', args.join(' '));
            return originalError.apply(logger, args);
        };
    }

    private addLogEntry(level: string, message: string, data?: any): void {
        const entry: LogEntry = {
            timestamp: Date.now(),
            level,
            message,
            data
        };
        
        this.recentLogs.push(entry);
        
        // Keep only recent logs
        if (this.recentLogs.length > this.maxLogEntries) {
            this.recentLogs.shift();
        }
        
        // Emit log event for real-time updates
        this.emit('log', entry);
    }

    private collectMetrics(): void {
        const systemStats = this.getSystemStats();
        
        // Emit metrics for real-time updates
        this.emit('metrics', {
            volume: this.volumeStats,
            system: systemStats,
            timestamp: Date.now()
        });
        
        // Check for alerts
        this.checkAlerts(systemStats);
    }

    private checkAlerts(systemStats: SystemStats): void {
        // Memory usage alert
        const memoryUsageMB = systemStats.memoryUsage.heapUsed / 1024 / 1024;
        if (memoryUsageMB > 512) { // 512MB threshold
            this.emit('alert', {
                type: 'high_memory_usage',
                message: `High memory usage: ${memoryUsageMB.toFixed(2)}MB`,
                severity: 'warning'
            });
        }
        
        // Daily volume limit alert
        if (this.volumeStats.dailyVolume > config.MAX_DAILY_VOLUME * 0.9) {
            this.emit('alert', {
                type: 'daily_volume_limit',
                message: `Daily volume approaching limit: $${this.volumeStats.dailyVolume.toFixed(2)}`,
                severity: 'warning'
            });
        }
        
        // Low success rate alert
        if (this.volumeStats.successRate < 0.8 && this.volumeStats.transactionCount > 10) {
            this.emit('alert', {
                type: 'low_success_rate',
                message: `Low success rate: ${(this.volumeStats.successRate * 100).toFixed(1)}%`,
                severity: 'error'
            });
        }
    }

    private resetDailyStats(): void {
        logger.info('🔄 Resetting daily volume statistics');
        this.volumeStats.dailyVolume = 0;
    }

    private resetHourlyStats(): void {
        this.volumeStats.hourlyVolume = 0;
    }

    public recordTransaction(volume: number, success: boolean): void {
        this.volumeStats.transactionCount++;
        
        if (success) {
            this.volumeStats.totalVolume += volume;
            this.volumeStats.dailyVolume += volume;
            this.volumeStats.hourlyVolume += volume;
        }
        
        // Update success rate (rolling average)
        const successCount = this.volumeStats.successRate * (this.volumeStats.transactionCount - 1) + (success ? 1 : 0);
        this.volumeStats.successRate = successCount / this.volumeStats.transactionCount;
        
        // Update average transaction value
        if (this.volumeStats.totalVolume > 0) {
            this.volumeStats.averageTransactionValue = this.volumeStats.totalVolume / this.volumeStats.transactionCount;
        }
        
        this.emit('transaction', {
            volume,
            success,
            stats: this.volumeStats
        });
    }

    public getStats(): VolumeStats & { system: SystemStats } {
        return {
            ...this.volumeStats,
            system: this.getSystemStats()
        };
    }

    private getSystemStats(): SystemStats {
        return {
            uptime: Date.now() - this.startTime,
            memoryUsage: process.memoryUsage(),
            activeConnections: process.listenerCount('connection') || 0
        };
    }

    public getRecentLogs(limit: number = 100): LogEntry[] {
        return this.recentLogs.slice(-limit);
    }

    public getVolumeHistory(hours: number = 24): { timestamp: number; volume: number }[] {
        // In a production system, this would query a database
        // For now, return mock data based on current stats
        const history = [];
        const now = Date.now();
        const interval = (hours * 60 * 60 * 1000) / 100; // 100 data points
        
        for (let i = 0; i < 100; i++) {
            history.push({
                timestamp: now - (99 - i) * interval,
                volume: Math.random() * this.volumeStats.hourlyVolume * 0.1
            });
        }
        
        return history;
    }

    public generateReport(): string {
        const uptime = Date.now() - this.startTime;
        const uptimeHours = Math.floor(uptime / (1000 * 60 * 60));
        const uptimeMinutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
        
        return `
=== Misty Volume Bot Report ===
Uptime: ${uptimeHours}h ${uptimeMinutes}m
Total Volume: $${this.volumeStats.totalVolume.toFixed(2)}
Daily Volume: $${this.volumeStats.dailyVolume.toFixed(2)}
Hourly Volume: $${this.volumeStats.hourlyVolume.toFixed(2)}
Transactions: ${this.volumeStats.transactionCount}
Success Rate: ${(this.volumeStats.successRate * 100).toFixed(1)}%
Avg Transaction: $${this.volumeStats.averageTransactionValue.toFixed(2)}
Memory Usage: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB
        `.trim();
    }
}
